#!/bin/bash

# Configuration for Neural Network
Configuration = 1

# Input size (number of features)
INPUT_SIZE=100

# Number of neurons in each hidden layer
HIDDEN_SIZES=(50 30 20 10 10 10)

# Output size (number of classes for classification or number of output neurons for regression)
OUTPUT_SIZE=10

# Task type: 'classification' or 'regression'
TASK='classification'

# Minimum total number of neurons required for the network
MIN_CAPACITY=5000

# Total number of neurons in the network
TOTAL_NEURONS=15550

# Number of training epochs
EPOCHS=1000

# Learning rate for training
LEARNING_RATE=0.02

# Path to input data file
INPUT_DATA_FILE="input_data.csv"

# Path to target data file (for supervised learning)
TARGET_DATA_FILE="target_data.csv"

# Path to save trained model
MODEL_PATH="model.pth"

# Path to training data
TRAINING_DATA="training_data.csv"

