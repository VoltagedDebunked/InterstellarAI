import csv

class DecisionTree:
    def __init__(self):
        self.tree = {}

    def train(self, X, y):
        self.tree = self._build_tree(X, y)

    def _build_tree(self, X, y):
        # Implement your tree building algorithm here
        # This could be a simple if-else tree based on the data

        # For simplicity, let's assume we have a pre-defined tree
        tree = {'feature': 'age', 'threshold': 30, 'left': 'class1', 'right': 'class2'}
        return tree

    def predict(self, X):
        predictions = []
        for sample in X:
            predictions.append(self._traverse_tree(sample, self.tree))
        return predictions

    def _traverse_tree(self, sample, node):
        if isinstance(node, str):  # Leaf node, return class label
            return node
        else:
            feature_value = sample[node['feature']]
            if feature_value <= node['threshold']:
                return self._traverse_tree(sample, node['left'])
            else:
                return self._traverse_tree(sample, node['right'])

# Load training data
def load_data(filename):
    with open(filename, 'r') as f:
        reader = csv.DictReader(f)
        X, y = [], []
        for row in reader:
            X.append({k: float(v) for k, v in row.items() if k != 'target'})
            y.append(row['target'])
    return X, y

X_train, y_train = load_data('training_data.csv')

# Train the model
model = DecisionTree()
model.train(X_train, y_train)

# Save the trained model (if needed)
# Example: You could serialize the tree structure to a file

# Make predictions
# Example: Load test data, call model.predict() and print predictions
