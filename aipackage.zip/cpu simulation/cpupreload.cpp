#include <iostream>
#include <vector>
#include <unordered_map>
#include <string>
#include <sstream>
#include <iomanip>

enum class InstructionType {
    ADD,
    SUB,
    MUL,
    DIV,
    LOAD,
    STORE,
    JUMP,
    CMP,
    BRANCH,
    HALT
};

struct Instruction {
    InstructionType type;
    int operand1;
    int operand2;
    int result;
};

class CPUSimulation {
private:
    std::vector<Instruction> program;
    std::unordered_map<int, int> memory;
    std::unordered_map<int, int> registers;
    int programCounter;

public:
    CPUSimulation(const std::vector<Instruction>& program) : program(program), programCounter(0) {
        for (int i = 0; i < 10; ++i) {
            registers[i] = 0;
        }
        for (int i = 0; i < 1024; ++i) {
            memory[i] = 0;
        }
    }

    void execute() {
        while (programCounter < program.size()) {
            const Instruction& instr = program[programCounter];
            switch (instr.type) {
                case InstructionType::ADD:
                    registers[instr.result] = registers[instr.operand1] + registers[instr.operand2];
                    break;
                case InstructionType::SUB:
                    registers[instr.result] = registers[instr.operand1] - registers[instr.operand2];
                    break;
                case InstructionType::MUL:
                    registers[instr.result] = registers[instr.operand1] * registers[instr.operand2];
                    break;
                case InstructionType::DIV:
                    if (registers[instr.operand2] != 0) {
                        registers[instr.result] = registers[instr.operand1] / registers[instr.operand2];
                    } else {
                        std::cerr << "Division by zero error!\n";
                    }
                    break;
                case InstructionType::LOAD:
                    registers[instr.result] = memory[instr.operand1];
                    break;
                case InstructionType::STORE:
                    memory[instr.operand1] = registers[instr.result];
                    break;
                case InstructionType::JUMP:
                    programCounter = instr.operand1;
                    continue;
                case InstructionType::CMP:
                    if (registers[instr.operand1] == registers[instr.operand2]) {
                        registers[31] = 0;
                    } else if (registers[instr.operand1] < registers[instr.operand2]) {
                        registers[31] = -1;
                    } else {
                        registers[31] = 1;
                    }
                    break;
                case InstructionType::BRANCH:
                    if (registers[31] == instr.operand2) {
                        programCounter = instr.operand1;
                        continue;
                    }
                    break;
                case InstructionType::HALT:
                    return;
                default:
                    std::cerr << "Unknown instruction type!\n";
                    break;
            }
            ++programCounter;
        }
    }

    void printState() {
        std::cout << "Registers:\n";
        for (const auto& reg : registers) {
            std::cout << "R" << std::setw(2) << std::setfill('0') << reg.first << ": " << std::setw(10) << reg.second << "\n";
        }

        std::cout << "Memory:\n";
        for (const auto& mem : memory) {
            std::cout << "Addr " << std::setw(4) << std::setfill('0') << mem.first << ": " << std::setw(10) << mem.second << "\n";
        }
    }
};

int main() {
    std::vector<Instruction> program = {
        {InstructionType::LOAD, 100, 0, 10},   // R10 = Mem[100]
        {InstructionType::ADD, 10, 20, 11},    // R11 = R10 + R20
        {InstructionType::STORE, 11, 200, 0},  // Mem[200] = R11
        {InstructionType::LOAD, 200, 0, 12},   // R12 = Mem[200]
        {InstructionType::MUL, 12, 13, 14},    // R14 = R12 * R13
        {InstructionType::STORE, 14, 300, 0},  // Mem[300] = R14
        {InstructionType::SUB, 14, 15, 16},    // R16 = R14 - R15
        {InstructionType::STORE, 16, 400, 0},  // Mem[400] = R16
        {InstructionType::HALT, 0, 0, 0}       // Halt
    };

    CPUSimulation cpu(program);
    cpu.execute();
    cpu.printState();

    return 0;
}
