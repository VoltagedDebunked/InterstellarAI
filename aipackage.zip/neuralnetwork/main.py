import numpy as np

class NeuralNetwork:
    def __init__(self, input_size, hidden_size, output_size):
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        
        # Initialize weights and biases
        self.W1 = np.random.randn(hidden_size, input_size)
        self.b1 = np.zeros((hidden_size, 1))
        self.W2 = np.random.randn(output_size, hidden_size)
        self.b2 = np.zeros((output_size, 1))

    def sigmoid(self, x):
        return 1 / (1 + np.exp(-x))

    def sigmoid_derivative(self, x):
        return x * (1 - x)

    def forward(self, inputs):
        self.z1 = np.dot(self.W1, inputs) + self.b1
        self.a1 = self.sigmoid(self.z1)
        self.z2 = np.dot(self.W2, self.a1) + self.b2
        self.a2 = self.sigmoid(self.z2)
        return self.a2

    def backward(self, inputs, targets, learning_rate):
        # Backpropagation
        error = targets - self.a2
        delta2 = error * self.sigmoid_derivative(self.a2)
        dW2 = np.dot(delta2, self.a1.T)
        db2 = np.sum(delta2, axis=1, keepdims=True)

        delta1 = np.dot(self.W2.T, delta2) * self.sigmoid_derivative(self.a1)
        dW1 = np.dot(delta1, inputs.T)
        db1 = np.sum(delta1, axis=1, keepdims=True)

        # Update weights and biases
        self.W1 += learning_rate * dW1
        self.b1 += learning_rate * db1
        self.W2 += learning_rate * dW2
        self.b2 += learning_rate * db2

    def train(self, inputs, targets, epochs, learning_rate):
        for epoch in range(epochs):
            for i in range(len(inputs)):
                input_data = inputs[i].reshape(-1, 1)
                target_data = targets[i].reshape(-1, 1)
                self.forward(input_data)
                self.backward(input_data, target_data, learning_rate)

    def predict(self, inputs):
        predictions = []
        for input_data in inputs:
            predictions.append(self.forward(input_data.reshape(-1, 1)))
        return np.array(predictions)

# Example usage:
# Define input and target data
inputs = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
targets = np.array([[0], [1], [1], [0]])

# Create and train the neural network
nn = NeuralNetwork(input_size=2, hidden_size=4, output_size=1)
nn.train(inputs, targets, epochs=1000, learning_rate=0.3)

# Make predictions
predictions = nn.predict(inputs)
print("Predictions:")
for i in range(len(inputs)):
    print(f"Input: {inputs[i]}, Predicted Output: {predictions[i][0]}")
