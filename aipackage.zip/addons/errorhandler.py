import math
import numpy as np

# Error fixer
try:

    pass
except ImportError:
    print("Runtime error detected! Please try again or try to find the issue with a compiler.")

    pass
except SyntaxError:
    print("Syntax error detected! Please review the code and make sure you didnt use libraries that you don't have installed.")

    pass
except NameError:
    print("Name error detected! Please review the name of the file because it may not match with the other files causing an error.")

    pass
except InterruptedError:
    print("Interruption error! Please make sure the code doesn't interfeere with other parts as it may cause problems while running.")
