def main():
    while True:
        try:
            epochs = int(input("Enter number of epochs to run: "))
            # Placeholder for loading data and initializing the model
            
            # Placeholder for training the model
            print("Training completed for", epochs, "epochs.")
        except ValueError:
            print("Please enter a valid number of epochs.")
            continue

if __name__ == "__main__":
    main()
